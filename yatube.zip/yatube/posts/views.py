from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404
from . import views
from .models import Post, Group

def index(request):
    """Выводим на страницу первые 10 записей постов."""

    posts = Post.objects.select_related('author')[:20]
    template = 'posts/index.html'
    context = {'posts': posts}
    return render(request, template, context)


#def index(request):
    # Одна строка вместо тысячи слов на SQL:
    # в переменную posts будет сохранена выборка из 10 объектов модели Post,
    # отсортированных по полю pub_date по убыванию (от больших значений к меньшим)
#    group = Group()
#    posts = Post.objects.order_by('-pub_date')[:10]
    # В словаре context отправляем информацию в шаблон
#    context = {
#        'group': group,
#        'posts': posts
#    }
#    return render(request, 'posts/index.html', context) 
    
# Create your views here.

#def index(request):
#    template = 'posts/index.html'
#    return render(request, template)
def group(request):
    group = Group()
    posts = Post.objects.order_by('-pub_date')[:10]
    context = {
        'group': group,
        'posts': posts,
    }
    template = 'posts/group_list.html'
    return render(request, template)

#def group_posts(request, slug):
#    group = get_object_or_404(Group, slug=slug)
#    posts = group.posts.all()[:12]
#    context = {
#        'group': group,
#        'posts': posts,
#    }
#    return render(request, 'posts/post.html', context)

def group_posts(request, slug):
    group = get_object_or_404(Group, slug=slug)
    posts = group.posts.all()[:12]
    return render(request, "posts/post.html", {"group": group, "posts": posts})

def group_help(request, slug):
    group = get_object_or_404(Group, slug=slug)
    posts = group.posts.all()[:12]
    return render(request, "includes/file.html", {"group": group, "posts": posts})
